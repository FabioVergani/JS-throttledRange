//import RangeThrottle from './dep/RangeThrottleClass.js';
import throttleRange from './dep/throttleRange.js';

//===========================================================
/* prettier-ignore */
const [
	//
	toggleRangeThrottle,
	rangeElem,
	outputRangeId,
	//
	toggleRangeThrottleFn,
	rangeElemFn,
	outputRangeIdFn,
] = [
  //test:class
	'toggle-range-throttle',
	'inputRangeId',
	'outputRangeId',
  //test:fn
	'toggle-range-throttle-fn',
	'inputRangeId-fn',
	'outputRangeId-fn',
].map(
	id => document.getElementById(id)
);
// console.log(inputRangeId.value);
/* prettier-ignore */
/*
const rangeThrottled = new RangeThrottle(
	rangeElem,
	(value,oldValue) => {
		outputRangeId.textContent = value;
		console.log(value,oldValue);
	},
	{stopped:true}
);
//console.dir(rangeThrottled);
toggleRangeThrottle.checked = rangeThrottled.enabled;
toggleRangeThrottle.addEventListener('change', () => {
	rangeThrottled[toggleRangeThrottle.checked ? 'start' : (console.clear(), 'stop')]();
});
*/

const throttledRange = throttleRange(
	rangeElemFn,
	(value,oldValue) => {
		outputRangeIdFn.textContent = value;
		console.log(value,oldValue);
	},
);
toggleRangeThrottleFn.checked = throttledRange.enabled;
/* prettier-ignore */
toggleRangeThrottleFn.addEventListener('change', () => {
	throttledRange[
		toggleRangeThrottleFn.checked 
			? 'start' 
			: (
				console.clear(),
				'stop'
			)
	]();
});
