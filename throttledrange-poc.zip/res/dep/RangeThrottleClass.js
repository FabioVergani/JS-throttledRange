/* prettier-ignore */
export default class RangeThrottle {
	#enabled;
	#handler;
	#element;
	get enabled() {
		return this.#enabled;
	}
	static listen(instance,bool){
		if (bool!==instance.#enabled) {
			instance.#element[
				(
					bool
						?'add'
						:'remove'
				)+'EventListener'
		  ](
				'input',
				instance.#handler
			);
			instance.#enabled = bool;
		}
	}
	start() {
		RangeThrottle.listen(this,true);
	}
	stop() {
		RangeThrottle.listen(this,false);
	}
	constructor(
		input, // element 🆁🅴🆀🆄🅸🆁🅴🅳
		callback, // function 🆁🅴🆀🆄🅸🆁🅴🅳
		options = {},
	) {
    this.#element = input;
		let 
			interval,
			previousValue = input.value;
		const 
			{
				setInterval,
				clearInterval
      } = input.ownerDocument.defaultView,
			fn = () => {
				const currentValue = input.value;
				if (currentValue !== previousValue) {
					callback(currentValue, previousValue);
					previousValue = currentValue;
        }
        clearInterval(interval);
        interval = null;
			},
			ms = options.delay || 150; // milliseconds
		this.#handler = () => {
      if(!interval){
        interval = setInterval(fn, ms);
      }
    };
		if (!options.stopped) {
			this.start();
		}
	}
}
